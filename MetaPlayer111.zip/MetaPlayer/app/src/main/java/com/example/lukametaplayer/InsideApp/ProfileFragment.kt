package com.example.lukametaplayer.InsideApp

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.text.InputType
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.example.lukametaplayer.R
import com.example.lukametaplayer.WelcomeActivity.LoginActivity
import com.example.lukametaplayer.models.UserName
import com.example.lukametaplayer.models.UserPhoto
import com.example.lukametaplayer.models.UserStatus
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"



private lateinit var imageProfile : ImageView
private lateinit var txtProfile : TextView
private lateinit var txtProfile2 : TextView
private lateinit var logOutBtn : Button
private val db = FirebaseDatabase.getInstance().getReference("UserName")
private val db1 = FirebaseDatabase.getInstance().getReference("UserStatus")
private val db2 = FirebaseDatabase.getInstance().getReference("UserPhoto")
private val auth = FirebaseAuth.getInstance()


class ProfileFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment ProfileFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            ProfileFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        imageProfile = view.findViewById(R.id.imageProfile)
        logOutBtn = view.findViewById(R.id.logOutBtn)
        txtProfile = view.findViewById(R.id.txt_profile)
        txtProfile2 = view.findViewById(R.id.txt_profile2)

        //TODO POFIKSIT CRASH PRI SMENE FRAGMENTA

        db.child(auth.currentUser?.uid!!).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val userStat = snapshot.getValue(UserName::class.java) ?:return
                txtProfile.text = userStat.name
            }
            override fun onCancelled(error: DatabaseError) {
            }

        })
        db1.child(auth.currentUser?.uid!!).addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                val userStatus = snapshot.getValue(UserStatus::class.java) ?:return
                txtProfile2.text = userStatus.status
            }

            override fun onCancelled(error: DatabaseError) {

            }

        })
        db2.child(auth.currentUser?.uid!!).addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                val userPhoto = snapshot.getValue(UserPhoto::class.java) ?:return
                Glide.with(this@ProfileFragment)
                    .load(userPhoto.photo).placeholder(R.drawable.profile).into(imageProfile)
            }

            override fun onCancelled(error: DatabaseError) {

            }

        })


        logOutBtn.setOnClickListener{
            MaterialAlertDialogBuilder(view.context)
                .setTitle(resources.getString(R.string.title))
                .setMessage(resources.getString(R.string.supporting_text))

                .setNegativeButton(resources.getString(R.string.decline)) { dialog, which ->

                }
                .setPositiveButton(resources.getString(R.string.accept)) { dialog, which ->
                    FirebaseAuth.getInstance().signOut()
                    logout()

                }

                .show()


        }
        txtProfile.setOnClickListener {
            showdialog()
        }
        txtProfile2.setOnClickListener {
            showdialog1()
        }
        imageProfile.setOnClickListener{
            showdialog2()
        }

    }
    fun showdialog(){
        val builder: AlertDialog.Builder = android.app.AlertDialog.Builder(activity)
        builder.setTitle("Change your name")

        val input = EditText(activity)
        input.setHint("Enter your name")
        input.inputType = InputType.TYPE_CLASS_TEXT
        builder.setView(input)
        builder.setPositiveButton("Submit", DialogInterface.OnClickListener { dialog, which ->
            var m_Text = input.text.toString()
//            DATABASE
//            -------
            val userStat = UserName(m_Text)
            db.child(auth.currentUser?.uid!!)
                .setValue(userStat)
        })
        builder.setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, which -> dialog.cancel() })
        builder.show()
    }
    fun showdialog1(){
        val builder: AlertDialog.Builder = android.app.AlertDialog.Builder(activity)
        builder.setTitle("Change your status")

        val input = EditText(activity)
        input.setHint("Enter your status")
        input.inputType = InputType.TYPE_CLASS_TEXT
        builder.setView(input)
        builder.setPositiveButton("Submit", DialogInterface.OnClickListener { dialog, which ->
            var status = input.text.toString()
//            DATABASE
//            -------
            val userStatus = UserStatus(status)
            db1.child(auth.currentUser?.uid!!)
                .setValue(userStatus)
        })
        builder.setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, which -> dialog.cancel() })
        builder.show()
    }
    fun showdialog2(){
        val builder: AlertDialog.Builder = android.app.AlertDialog.Builder(activity)
        builder.setTitle("Change your picture")

        val input = EditText(activity)
        input.setHint("Enter url")
        input.inputType = InputType.TYPE_CLASS_TEXT
        builder.setView(input)
        builder.setPositiveButton("Submit", DialogInterface.OnClickListener { dialog, which ->
            var m_Text = input.text.toString()
//            DATABASE
//            -------
            val userPhoto = UserPhoto(m_Text)
            db2.child(auth.currentUser?.uid!!)
                .setValue(userPhoto)
        })
        builder.setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, which -> dialog.cancel() })
        builder.show()
    }
    private fun logout(){
        startActivity(Intent(activity, LoginActivity::class.java))
        activity?.finish()

    }


}