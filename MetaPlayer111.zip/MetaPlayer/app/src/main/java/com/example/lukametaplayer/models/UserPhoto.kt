package com.example.lukametaplayer.models

data class UserPhoto(
    val photo: String = ""
)
