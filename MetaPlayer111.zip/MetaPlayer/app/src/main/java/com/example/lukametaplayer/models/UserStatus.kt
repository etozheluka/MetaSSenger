package com.example.lukametaplayer.models

data class UserStatus(
    val status: String = ""
)
