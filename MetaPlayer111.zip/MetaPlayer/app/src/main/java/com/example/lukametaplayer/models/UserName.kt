package com.example.lukametaplayer.models

data class UserName(
    val name: String = ""
)
