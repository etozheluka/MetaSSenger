package com.example.lukametaplayer.InsideApp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.lukametaplayer.R
import com.example.lukametaplayer.models.UserName
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.xwray.groupie.GroupAdapter
import com.xwray.groupie.Item
import com.xwray.groupie.ViewHolder
import kotlinx.android.synthetic.main.activity_message.*
import kotlinx.android.synthetic.main.card_layout.view.*


class MessageActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_message)
        supportActionBar?.title = "Select User"
        showUsers()



    }

    private fun showUsers() {
        val reference = FirebaseDatabase.getInstance().getReference("/userName")
        reference.addListenerForSingleValueEvent(object : ValueEventListener{

            override fun onDataChange(snapshot: DataSnapshot) {

                val adapter = GroupAdapter<ViewHolder>()

                snapshot.children.forEach{
                    val name = it.getValue(UserName::class.java)
                    if (name != null){
                        adapter.add(UserItem(name))
                    }

                }
                recyclerView.adapter = adapter

            }

            override fun onCancelled(error: DatabaseError) {

            }
        })
    }

    class UserItem(val name: UserName) : Item<ViewHolder>() {
        override fun bind(viewHolder: ViewHolder, position: Int) {
            viewHolder.itemView.title.text = name.name
        }

        override fun getLayout(): Int {
            return R.layout.card_layout
        }
    }


}